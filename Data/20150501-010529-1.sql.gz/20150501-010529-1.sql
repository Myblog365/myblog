-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 120.26.70.41
-- Port     : 3306
-- Database : myblog
-- 
-- Part : #1
-- Date : 2015-05-01 01:05:29
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `th_Qiniu`
-- -----------------------------
DROP TABLE IF EXISTS `th_Qiniu`;
CREATE TABLE `th_Qiniu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `url` varchar(100) NOT NULL DEFAULT '' COMMENT '文件url',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  `download` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `th_access`
-- -----------------------------
DROP TABLE IF EXISTS `th_access`;
CREATE TABLE `th_access` (
  `role_id` smallint(6) unsigned NOT NULL,
  `node_id` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) NOT NULL,
  `pid` smallint(6) NOT NULL,
  `module` varchar(50) DEFAULT NULL,
  KEY `groupId` (`role_id`),
  KEY `nodeId` (`node_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `th_addons`
-- -----------------------------
DROP TABLE IF EXISTS `th_addons`;
CREATE TABLE `th_addons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL COMMENT '插件名或标识',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '中文名',
  `description` text COMMENT '插件描述',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `config` text COMMENT '配置',
  `author` varchar(40) DEFAULT '' COMMENT '作者',
  `version` varchar(20) DEFAULT '' COMMENT '版本号',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间',
  `has_adminlist` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '是否有后台列表',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=508 DEFAULT CHARSET=utf8 COMMENT='插件表';

-- -----------------------------
-- Records of `th_addons`
-- -----------------------------
INSERT INTO `th_addons` VALUES ('16', 'Avatar', '头像插件', '用于头像的上传', '1', '{\"random\":\"1\"}', 'caipeichao', '0.1', '1394449710', '1');
INSERT INTO `th_addons` VALUES ('41', 'LocalComment', '本地评论', '本地评论插件，不依赖社会化评论平台', '1', '{\"can_guest_comment\":\"1\"}', 'caipeichao', '0.1', '1399440324', '0');
INSERT INTO `th_addons` VALUES ('500', 'seo', 'seo设置', '方便站长自定义seo关键词等', '1', '{\"type\":\"0\",\"indextitle\":\"\",\"indexkey\":\"\",\"indexdes\":\"\",\"hottitle\":\"\",\"hotkey\":\"\",\"hotdes\":\"\",\"zantitle\":\"\",\"zankey\":\"\",\"zandes\":\"\",\"gztitle\":\"\",\"gzkey\":\"\",\"gzdes\":\"\",\"contitle\":\"\",\"conkey\":\"\",\"condes\":\"\",\"uctitle\":\"\",\"uckey\":\"\",\"ucdes\":\"\",\"regtitle\":\"\",\"regkey\":\"\",\"regdes\":\"\",\"logintitle\":\"\",\"loginkey\":\"\",\"logindes\":\"\",\"pstitle\":\"\",\"pskey\":\"\",\"psdes\":\"\",\"tltitle\":\"\",\"tlkey\":\"\",\"tldes\":\"\",\"sltitle\":\"\",\"slkey\":\"\",\"sldes\":\"\",\"cltitle\":\"\",\"clkey\":\"\",\"cldes\":\"\",\"attitle\":\"\",\"atkey\":\"\",\"atdes\":\"\"}', 'zswin', '0.1', '1430141850', '0');
INSERT INTO `th_addons` VALUES ('501', 'SuperLinks', '友情链接', '友情链接', '1', '{\"random\":\"1\"}', '苏南 newsn.net', '0.1', '1430141858', '1');
INSERT INTO `th_addons` VALUES ('502', 'ImageSlider', '图片轮播', '图片轮播', '1', '{\"second\":\"3000\",\"url\":\"\",\"images\":\"\"}', 'birdy', '0.2', '1430141868', '0');
INSERT INTO `th_addons` VALUES ('503', 'Advertising', '广告位置', '广告位插件', '1', 'null', 'onep2p', '0.1', '1430141874', '1');
INSERT INTO `th_addons` VALUES ('504', 'Advs', '广告管理', '广告插件', '1', 'null', 'onep2p', '0.1', '1430141879', '1');
INSERT INTO `th_addons` VALUES ('505', 'cnzz', '站长统计', '只是给用户提供填站长统计代码的地方', '1', '{\"cnzz\":\"<script type=\\\"text\\/javascript\\\">var cnzz_protocol = ((\\\"https:\\\" == document.location.protocol) ? \\\" https:\\/\\/\\\" : \\\" http:\\/\\/\\\");document.write(unescape(\\\"%3Cspan id=\'cnzz_stat_icon_1254914572\'%3E%3C\\/span%3E%3Cscript src=\'\\\" + cnzz_protocol + \\\"s11.cnzz.com\\/z_stat.php%3Fid%3D1254914572%26online%3D1%26show%3Dline\' type=\'text\\/javascript\'%3E%3C\\/script%3E\\\"));<\\/script>\"}', 'zswin', '0.1', '1430141891', '0');
INSERT INTO `th_addons` VALUES ('506', 'Qiniu', '七牛存储插件', '用于七牛存储的上传', '1', '{\"open\":\"1\",\"global\":\"1\",\"secrectKey\":\"31BMePSLtnrquPr5uXgOiCii-_S8vVY0pIobQU9V\",\"accessKey\":\"9j4-N40OrKM7UelTtijcr9P5Ka_LgTcQfucHQjYG\",\"domain\":\"7xiuw8.com1.z0.glb.clouddn.com\",\"bucket\":\"myblog\"}', 'zswin', '0.1', '1430404197', '1');
INSERT INTO `th_addons` VALUES ('507', 'Fancybox', '图片弹出播放', '让文章内容页的图片有弹出图片播放的效果', '1', '{\"group\":\"1\",\"transitionIn\":\"fade\",\"transitionOut\":\"fade\",\"padding\":\"10\",\"hideOnContentClick\":\"true\",\"easingIn\":\"easeOutCubic\"}', 'che1988', '0.1', '1430412346', '0');

-- -----------------------------
-- Table structure for `th_advertising`
-- -----------------------------
DROP TABLE IF EXISTS `th_advertising`;
CREATE TABLE `th_advertising` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '广告位置名称',
  `type` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '广告位置展示方式  0为默认展示一张',
  `width` char(20) NOT NULL DEFAULT '' COMMENT '广告位置宽度',
  `height` char(20) NOT NULL DEFAULT '' COMMENT '广告位置高度',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `pos` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告位置表';

-- -----------------------------
-- Records of `th_advertising`
-- -----------------------------
INSERT INTO `th_advertising` VALUES ('1', '评论框上方', '2', '620', '87', '1', 'up_commentbox');
INSERT INTO `th_advertising` VALUES ('2', '右侧边栏下方', '4', '', '', '1', 'below_sidebar');
INSERT INTO `th_advertising` VALUES ('3', '首页头条下方广告位', '1', '756', '100', '1', 'home_ad1');

-- -----------------------------
-- Table structure for `th_advs`
-- -----------------------------
DROP TABLE IF EXISTS `th_advs`;
CREATE TABLE `th_advs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` char(80) NOT NULL DEFAULT '' COMMENT '广告名称',
  `position` int(11) NOT NULL COMMENT '广告位置',
  `advspic` int(11) NOT NULL COMMENT '图片地址',
  `advstext` text NOT NULL COMMENT '文字广告内容',
  `advshtml` text NOT NULL COMMENT '代码广告内容',
  `link` char(140) NOT NULL DEFAULT '' COMMENT '链接地址',
  `level` int(3) unsigned NOT NULL DEFAULT '0' COMMENT '优先级',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态（0：禁用，1：正常）',
  `create_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '开始时间',
  `end_time` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '结束时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='广告表';


-- -----------------------------
-- Table structure for `th_article`
-- -----------------------------
DROP TABLE IF EXISTS `th_article`;
CREATE TABLE `th_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(255) NOT NULL DEFAULT '' COMMENT '标题',
  `description` text NOT NULL COMMENT '内容',
  `thumb` varchar(200) DEFAULT NULL,
  `uid` int(10) DEFAULT '0' COMMENT '用户ID',
  `cid` int(10) DEFAULT '0' COMMENT '分类',
  `view` int(10) DEFAULT '0' COMMENT '查看数',
  `sccount` int(10) DEFAULT '0' COMMENT '收藏',
  `reply_count` int(10) DEFAULT '0' COMMENT '评论数',
  `ding` int(10) DEFAULT '0' COMMENT '支持',
  `cai` int(10) DEFAULT '0' COMMENT '反对',
  `tj` tinyint(1) DEFAULT '0' COMMENT '1推荐2置顶3全局置顶',
  `tag` varchar(255) DEFAULT '' COMMENT '标签',
  `copyright` varchar(255) DEFAULT '' COMMENT '版权信息',
  `status` tinyint(1) DEFAULT '0' COMMENT '审核状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_article`
-- -----------------------------
INSERT INTO `th_article` VALUES ('1', 'Mysql备份shell脚本', '有时候莫名的出现数据库出问题，所有数据导致用不了。\r\n备份还是非常重要的，以防出现问题，及时补救。\r\n脚本如下\r\n<pre>\r\n<code data-language=\'shell\'>\r\n#!/bin/sh\r\n# File: /var/www/shell/mysql_back.sh \r\n# Database info \r\nDB_NAME=\"dbname\" \r\nDB_USER=\"root\" \r\nDB_PASS=\"123456\" \r\n# Others vars\r\n # 如果你的系统需要进入bin目录，则就写这一条，有的系统不用进入bin目录也可以 \r\nBIN_DIR=\"/usr/local/mysql/bin\" \r\nBCK_DIR=\"/var/www/shell/sqlback\" \r\nDATE=`date +%F` # TODO \r\n$BIN_DIR/mysqldump -u$DB_USER -p$DB_PASS $DB_NAME | gzip &gt;$BCK_DIR/adm_$DATE.gz\r\n</code>\r\n</pre>\r\n写一个脚本，配合crontab -e 定时计划，也不会太麻烦，很省事省心。', '', '1', '3', '348', '0', '0', '2', '0', '1', '', '', '1', '1430143622', '1430236868');
INSERT INTO `th_article` VALUES ('3', 'Mysql常见存储引擎--MyISAM和InnoDB的区别', 'MySQL中最常见的数据引擎就是MyISAM和InnoDB，MyISAM适合查询以及插入为主的应用，InnoDB适合频繁修改以及涉及到安全性要求高的应用，两者的一些差别如下(部分借鉴来源于网络，以下只是记录着个人的学习记录)：<br />\r\n<br />\r\n1、MyISAM不支持事务和外健关联，而InnoDB支持事务和外健关联。事务是一种高级的处理方式，可以把一连贯的操作过程中，只要哪个环节出错还可以回滚还原，而MyISAM就不可以了。比如用户下订单，用户支付了100元，店家收到了100元，但是由于各种原因用户支付环节出错了，店家可不能莫名多了100元，这时候就涉及到事务的回滚，优势就上来了。<br />\r\n<br />\r\n2、MyISAM的索引和数据是分开的，并且索引是有压缩的，内存使用率就对应提高了不少，能加载更多索引。而Innodb是索引和数据是紧密捆绑的，没有使用压缩从而会造成Innodb比MyISAM体积要庞大，在海量数据的网站级别中尤能体现。MyISAM类型的数据文件相对小，还可以在不同操作系统中COPY库中frm.MYD,MYI的文件，这点还是很有优势，布署的时候方便。<br />\r\n<br />\r\n3、InnoDB中不保存表的行数，如select count(*) from table时，InnoDB需要扫描一遍整个表来计算有多少行，但是MyISAM只要简单的读出保存好的行数即可。注意的是，当count(*)语句包含where条件时MyISAM也需要扫描整个表。<br />\r\n<br />\r\n4、删除表时，DELETE FROM table时，InnoDB不会重新建立表，而是一行一行的删除，效率要慢。而MyISAM则会重新建立表。<br />\r\n<br />\r\n5、InnoDB会造成行级锁，锁了行，其他的操作需要等待，等待释放资源才会进行操作。当然等待的是微乎其微的，只有海量数据级别的网站才会体现。InnoDB表的行锁也不是绝对的，还可能锁表，假如在执行一个SQL语句时MySQL不能确定要扫描的范围，例如update table set num=1 where name like “%aaa%”，InnoDB表同样会锁全表。同时这种情况也会锁表，where条件中，非主键的都会锁全表的。<br />\r\n<br />\r\n6、MyISAM总体执行效率快，对比insert写操作的话，MyISAM的写性能比InnoDB要高效，如果是针对基于索引的update操作，Innodb会比MyISAM有优势。<br />\r\n<br />\r\n没有绝对好坏，实际应用中，根据不同需求来优化，设计。<br />', 'image/20150430/20150430131135_72242.jpg', '1', '2', '2', '0', '0', '1', '0', '1', '', '', '1', '1430370722', '1430370722');
INSERT INTO `th_article` VALUES ('2', 'PHP计算几分钟前的例子', '我们经常在一些微博、空间、或则看新闻时，都会显示几分钟前，几天前发布了说说，更新了微博。\r\n等等。像这样的一个时间的算计，应用是非常广的。而同时对于新闻资讯或则信息更新，时间是一个\r\n唯一的实效性，同时在互联网中也是非常注重信息的实效性，最新状态。\r\n    那么使用PHP来计算这么一个时间，其实原理很简单的，在取出数据显示的时候，进行一个函数的调用，\r\n 函数如下：\r\n <pre>\r\n <code data-language=\'php\'>\r\n \r\nfunction formate_date($time)\r\n{\r\n    $diff_time = time() - $time;\r\n    $year = 24*3600*365;\r\n    $month = 24*3600*30;\r\n    $week = 24*3600*7;\r\n    $day = 24*3600;\r\n    $hour = 3600;\r\n    $minute = 60;\r\n    $second = 1;\r\n    $diff_arr=array(\r\n        $year => \'年\',\r\n        $month => \'个月\',\r\n        $week => \'星期\',\r\n        $day => \'天\',\r\n        $hour => \'小时\',\r\n        $minute => \'分钟\',\r\n        $second  => \'秒\',\r\n    );\r\n\r\n    foreach($diff_arr as $k => $val)\r\n    {   \r\n        $t = floor($diff_time/(int)$k);\r\n        if(0 != $t)\r\n        {\r\n            return $t.$val.\'前\';\r\n        }\r\n    }\r\n}\r\n\r\n</code>\r\n</pre>\r\n其实很简单，但是却很实用。', '', '1', '1', '84', '0', '2', '2', '0', '1', '', '', '1', '1430157809', '1430238613');
INSERT INTO `th_article` VALUES ('4', '数组比较大小排序', '之前做过一个任务，涉及到排序的问题，如果要自己写一个排序法其实也可以，\r\n后来发现原来有这么用的，usort的第二个参数可以自定义函数，底下的例子中 这里的9999与-1 有不一样的效果。\r\n<pre>\r\n<code data-language=\'php\'>\r\nusort($arr,\'orderCorrect_cmp\')   \r\n//按照某一种排序，从低到高\r\nfunction orderCorrect_cmp($a, $b)\r\n{\r\n    $a=($a[\'avail_st\']==\'-\')?-1:$a[\'avail_st\'];\r\n    $b=($b[\'avail_st\']==\'-\')?-1:$b[\'avail_st\'];\r\n    if ($a == $b) {\r\n        return 0;\r\n    }\r\n    return ($a > $b) ? -1 : 1;\r\n}\r\n\r\n//按照某一种排序，从低到高\r\nfunction avg_avail_cmp($a, $b)\r\n{\r\n    $a=($a[\'avg_avail\']==\'-\')?9999:$a[\'avg_avail\'];\r\n    $b=($b[\'avg_avail\']==\'-\')?9999:$b[\'avg_avail\'];\r\n    if ($a == $b) {\r\n        return 0;\r\n    }\r\n    return ($a > $b) ? 1 : -1;\r\n}\r\n</code>\r\n</pre>', '', '1', '1', '4', '0', '0', '1', '0', '1', '', '', '1', '1430373726', '1430373726');
INSERT INTO `th_article` VALUES ('5', 'ubuntu下安装LAMP环境', '直接一条命令：apt-get install apache2 mysql-server mysql-client php5 php5-gd php5-mysql<br />\r\n<br />\r\n设置Ubuntu文件执行读写权限<br />\r\n<br />\r\n<p>\r\n	LAMP 组建安装好之后，PHP网络服务器根目录默认设置是在：/var/www。由于Linux系统的安全性原则，改 目录下的文件读写权限是只允许root用户操作的，所以我们不能在www文件夹中新建php文件，也不能修改和删除，必须要先修改/var/www目录的 读写权限。在界面管理器中通过右键属性不能修改文件权限，得执行root终端命令：sudo chmod 777 /var/www。然后就可以写入html或php文件了。\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n如何安装phpmyadmin-Mysql 数据库管理<br />\r\n<br />\r\n使用界面管理器：<br />\r\n<br />\r\n系统->系统管理->新立得软件包管理器->搜索 phpmyadmin->右键标记安装。<br />\r\n<br />\r\n或直接使用一条命令：sudo apt-get install phpmyadmin 安装开始。<br />\r\n<br />\r\nphpmyadmin设置：<br />\r\n<br />\r\n在 安装过程中会要求选择Web server：apache2或lighttpd，选择apache2，按tab键然后确定。然后会要求输入设置的Mysql数据库密码连接密码 Password of the database’s administrative user。<br />\r\n<br />\r\n然后将phpmyadmin与 apache2建立连接，以我的为例：www目录在/var/www，phpmyadmin在/usr/share/phpmyadmin目录，所以就用 命令：sudo ln -s /usr/share/phpmyadmin /var/www 建立连接。<br />\r\n<br />\r\nphpmyadmin测试：在浏览器地址栏中打开http://localhost/phpmyadmin。<br />\r\n<br />\r\nUbuntu LAMP 如何配置Apache<br />\r\n<br />\r\n1. 启用 mod_rewrite 模块<br />\r\n<br />\r\n终端命令：sudo a2enmod rewrite<br />\r\n<br />\r\n重启Apache服务器：sudo /etc/init.d/apache2 restart<br />\r\n<br />\r\nApache 重启后我们可以测试一下，在/var/www目录下新建文件test.php，写入代码：   保存，在地址栏输入http://127.0.0.1/test.php 或 http://localhost/test.php ，如果正确出现了php 配置信息则表明LAMP Apache已经正常工作了(记得重启Apache服务器后再测试)。<br />\r\n<br />\r\n2.设置Apache支持.htm .html .php<br />\r\n<br />\r\nsudo gedit /etc/apache2/apache2.conf<br />\r\n<br />\r\n或sudo gedit /etc/apache2/mods-enabled/php5.conf<br />\r\n<br />\r\n在打开的文件中加上<br />\r\n<br />\r\nAddType application/x-httpd-php .php .htm .html 即可。<br />\r\n<br />\r\nLAMP配置之Mysql测试<br />\r\n<br />\r\n上面php,Apache 都已经测试过了，下面我们再测试一下Mysql 数据库是否已经正确启用。<br />\r\n<br />\r\n在/var/www目录下新建 mysql_test.php：<br />\r\n<br />\r\n$link = mysql_connect(\"localhost\",\"root\",\"020511\");<br />\r\n<br />\r\nif (!$link)<br />\r\n<br />\r\n{<br />\r\n<br />\r\ndie(\'Could not connect: \' . mysql_error());<br />\r\n<br />\r\n}<br />\r\n<br />\r\nelse echo \"Mysql已经正确配置\";<br />\r\n<br />\r\nmysql_close($link);<br />\r\n<br />\r\n?><br />\r\n<br />\r\n保存退出，在地址栏输入http://127.0.0.1/mysql_test.php，显示”Mysql 已经正确配置”则表示OK了，如果不行，重启Apache服务器后再试一下。<br />\r\n<br />\r\n解决Firefox浏览器显示中文乱码等问题<br />\r\n<br />\r\n上面在FireFox浏览器中打开mysql_test.php或phpmyadmin测试时，如果出现了中文乱码，则是默认语言设置问题，解决方法如下：<br />\r\n<br />\r\n打开apache配置文件： udo gedit /etc/apache2/apache2.conf，在最后面加上：AddDefaultCharset UTF-8，如果还是乱码的，再将UTF-8改用gb2312。<br />\r\n<br />\r\n重启Apache：sudo /etc/init.d/apache2 restart  再刷新mysql_test.php 中文乱码没有了。<br />\r\n<br />\r\n如果要人工启动mysql：mysql -u root -p，根据提示输入密码。<br />\r\n<br />\r\n如果重启Apache时出现：<br />\r\n<br />\r\n* Restarting web server apache2<br />\r\n<br />\r\napache2: Could not reliably determine the server’s fully qualified domain name, using 127.0.1.1 for ServerName<br />\r\n<br />\r\napache2: Could not reliably determine the server’s fully qualified domain name, using 127.0.1.1 for ServerName<br />\r\n<br />\r\n则还是修改apache配置文件：sudo gedit /etc/apache2/apache2.conf，在文件最后设置：ServerName 127.0.0.1<br />\r\n<br />\r\nLAMP组件经常使用的几个终端命令<br />\r\n<br />\r\n重启 apache：sudo /etc/init.d/apache2 restart<br />\r\n<br />\r\n重启mysql：sudo /etc/init.d/mysql restart<br />\r\n<br />\r\n配置 php.ini：sudo gedit /etc/php5/apache2/php.ini<br />\r\n<br />\r\n配置 apache2.conf：sudo gedit /etc/apache2/apache2.conf<br />\r\n<br />\r\n配置 my.cnf：sudo gedit /etc/mysql/my.cnf<br />\r\n<br />\r\nPHP CGI ：sudo /var/www/cgi-bin/', 'image/20150430/20150430214728_91949.png', '1', '3', '2', '0', '0', '0', '0', '0', '', '', '1', '1430401656', '1430401679');
INSERT INTO `th_article` VALUES ('6', 'Ubuntu下安装IDE--phpStorm', '&nbsp;&nbsp;&nbsp;&nbsp;开发过程中，使用IDE这种软件，比起普通的编辑器有着很多的优势。在window下使用，非常卡，而在Linux下运行非常流畅<br />\r\n&nbsp;&nbsp;&nbsp; ubuntu下装phpStorm之前要先装JDK，sudo apt-get install oracle-java8-installer<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp; ubuntu下安装oracle java8<br />\r\n&nbsp;&nbsp;&nbsp; 首先要添加ppa<br />\r\n&nbsp;&nbsp;&nbsp; $ sudo add-apt-repository ppa:webupd8team/java<br />\r\n&nbsp;&nbsp;&nbsp; 然后更新系统<br />\r\n&nbsp;&nbsp;&nbsp; $ sudo apt-get update<br />\r\n&nbsp;&nbsp;&nbsp; 最后开始安装<br />\r\n<p>\r\n	&nbsp;&nbsp;&nbsp; $ sudo apt-get install oracle-java8-installer\r\n</p>\r\n<p>\r\n	&nbsp;&nbsp;&nbsp; 接着查看版本\r\n</p>\r\n&nbsp;&nbsp;&nbsp; $ java -version<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; java version \"1.8.0_05\"<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Java(TM) SE Runtime Environment (build 1.8.0_05-b13)<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; Java HotSpot(TM) Server VM (build 25.5-b02, mixed mode)<br />\r\n&nbsp;&nbsp;&nbsp; 如果java版本要切换<br />\r\n<p>\r\n	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; sudo update-java-alternatives -s java-8-oracle\r\n</p>\r\n<p>\r\n	<br />\r\n</p>\r\n<p>\r\n	如果你在装JDk时，没有那么顺利成功装上，请手动进行一些配置\r\n</p>\r\n<p>\r\n	JDK的环境安装和配置：<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a target=\"_blank\" href=\"http://my.oschina.net/jamesju/blog/94916\">http://my.oschina.net/jamesju/blog/94916</a>\r\n</p>\r\n<p>\r\n	<br />\r\n</p>', 'image/20150430/20150430215546_21798.png', '1', '3', '2', '0', '0', '0', '0', '0', '', '', '1', '1430402472', '1430402472');
INSERT INTO `th_article` VALUES ('7', 'virtualBox共享文件夹', '<p>\r\n	&nbsp;&nbsp;&nbsp;&nbsp;virtualBox比起Vmware，&nbsp; virtualBox性能更优越，占用资源更少。\r\n</p>\r\n<p>\r\n	如果你的个人电脑需要虚拟机，建议你可以考虑用这一款。\r\n</p>\r\n<p>\r\n	&nbsp;&nbsp;&nbsp; 当你装的虚拟机是Linux系统的话，对于共享文件不是简单的在&nbsp;virtualBox面板上，简单点击操作就可以的。\r\n</p>\r\n<p>\r\n	&nbsp;&nbsp; 还需要进入虚拟机系统，进行挂载磁盘。\r\n</p>\r\n<p>\r\n	&nbsp;&nbsp;&nbsp;&nbsp;<strong>挂载共享文件夹</strong><br />\r\n以Ubuntu为例进入虚拟Ubuntu，在命令行终端下输入：<br />\r\nsudo mkdir /mnt/shared<br />\r\nsudo mount -t vboxsf share /mnt/shared<br />\r\n其中\"share\"是之前创建的共享文件夹的名字（在virtualBox面板上设置的）。OK，现在Ubuntu和主机可以互传文件了。<br />\r\n<br />\r\n要想自动挂载的话，可以在/etc/fstab中添加一项<br />\r\nshare /mnt/shared vboxsf rw,gid=100,uid=1000,auto 0 0<br />\r\n&nbsp;&nbsp;&nbsp;&nbsp;卸载的话使用下面的命令：<br />\r\nsudo umount -f /mnt/shared<br />\r\n<br />\r\n注意：<br />\r\n共享文件夹的名称 千万不要和挂载点的名称相同。比如，上面的挂载点是/mnt/shared，如果共享文件夹的名字也是shared的话，在挂载的时候就会出现如下的错误 信息：/sbin/mount.vboxsf: mounting failed with the error: Protocol error\r\n</p>', 'image/20150430/20150430220710_63155.png', '1', '3', '0', '0', '0', '0', '0', '0', '', '', '1', '1430403359', '1430403359');
INSERT INTO `th_article` VALUES ('8', 'CURL对于https协议报错处理方式', '<p>\r\n	CURL对于https协议问题，之前自己在开发过程中，还真的遇到此问题，后来才明白。\r\n</p>\r\n<p>\r\n	由于https协议需要有安全证书验证，\r\n</p>\r\n<p>\r\n	所以当PHP通过CURL访问https时可能会出现SSL certificate problem: unable to get local issuer certificate的解决方法：\r\n</p>\r\n<p>\r\n	只要设置以下两个属性就可以解决。\r\n</p>\r\n将 CURLOPT_SSL_VERIFYPEER 设置为 false,<br />\r\n将 CURLOPT_SSL_VERIFYHOST 设置为 false.', '', '1', '1', '1', '0', '0', '0', '0', '0', '', '', '1', '1430412958', '1430413029');

-- -----------------------------
-- Table structure for `th_avatar`
-- -----------------------------
DROP TABLE IF EXISTS `th_avatar`;
CREATE TABLE `th_avatar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `path` varchar(200) NOT NULL,
  `create_time` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `is_temp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=158 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_avatar`
-- -----------------------------
INSERT INTO `th_avatar` VALUES ('157', '1', '20150428/553fa8cee3b95-bb4218b4.jpg', '1430235365', '1', '0');

-- -----------------------------
-- Table structure for `th_cate`
-- -----------------------------
DROP TABLE IF EXISTS `th_cate`;
CREATE TABLE `th_cate` (
  `id` smallint(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `des` varchar(255) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT '0',
  `pid` smallint(4) unsigned NOT NULL DEFAULT '0',
  `spid` varchar(50) NOT NULL,
  `ordid` smallint(4) unsigned NOT NULL DEFAULT '255',
  `type` tinyint(1) DEFAULT '1' COMMENT '分类类型',
  `enable` tinyint(1) DEFAULT '1' COMMENT '会员是否可发布',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_cate`
-- -----------------------------
INSERT INTO `th_cate` VALUES ('1', 'PHP编程', '', '', '0', '0', '255', '1', '1', '1');
INSERT INTO `th_cate` VALUES ('2', 'Mysql', '', '', '0', '0', '255', '1', '1', '1');
INSERT INTO `th_cate` VALUES ('3', 'Linux', '', '', '0', '0', '255', '1', '1', '1');
INSERT INTO `th_cate` VALUES ('4', '个人随笔', '', '', '0', '0', '255', '1', '1', '1');

-- -----------------------------
-- Table structure for `th_config`
-- -----------------------------
DROP TABLE IF EXISTS `th_config`;
CREATE TABLE `th_config` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '配置ID',
  `name` varchar(30) NOT NULL DEFAULT '' COMMENT '配置名称',
  `type` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置类型',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '配置说明',
  `groupid` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '配置分组',
  `extra` varchar(255) NOT NULL DEFAULT '' COMMENT '配置值',
  `remark` varchar(100) NOT NULL COMMENT '配置说明',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  `value` text NOT NULL COMMENT '配置值',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0' COMMENT '排序',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_name` (`name`),
  KEY `type` (`type`),
  KEY `groupid` (`groupid`)
) ENGINE=MyISAM AUTO_INCREMENT=500 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_config`
-- -----------------------------
INSERT INTO `th_config` VALUES ('1', 'WEB_SITE_TITLE', '1', '网站标题', '1', '', '网站标题前台显示标题', '1378898976', '1379235274', '1', 'Myblog365博客', '0');
INSERT INTO `th_config` VALUES ('2', 'WEB_SITE_DESCRIPTION', '2', '网站描述', '1', '', '网站搜索引擎描述', '1378898976', '1379235841', '1', 'Myblog365博客是专注于php技术交流与讨论的博客网站。Myblog365博客，分享交流php教程、相关编程技术编程思维。欢迎你来Myblog365博客分享php博客文摘，以及php技术交流.。', '1');
INSERT INTO `th_config` VALUES ('3', 'WEB_SITE_KEYWORD', '2', '网站关键字', '1', '', '网站搜索引擎关键字', '1378898976', '1381390100', '1', 'PHP交流,PHP技术,PHP博客,博客交流', '8');
INSERT INTO `th_config` VALUES ('4', 'WEB_SITE_CLOSE', '4', '关闭站点', '1', '0:关闭,1:开启', '站点关闭后其他用户不能访问，管理员可以正常访问', '1378898976', '1379235296', '1', '1', '1');
INSERT INTO `th_config` VALUES ('9', 'CONFIG_TYPE_LIST', '3', '配置类型列表', '4', '', '主要用于数据解析和页面表单的生成', '1378898976', '1379235348', '1', '0:数字\r\n1:字符\r\n2:文本\r\n3:数组\r\n4:枚举\r\n5:富文本\r\n6:密码', '2');
INSERT INTO `th_config` VALUES ('10', 'WEB_SITE_ICP', '1', '网站备案号', '1', '', '设置在网站底部显示的备案号，如“沪ICP备12007941号-2', '1378900335', '1379235859', '1', '', '9');
INSERT INTO `th_config` VALUES ('20', 'CONFIG_GROUP_LIST', '3', '配置分组', '4', '', '配置分组', '1379228036', '1419497120', '1', '1:基本\r\n2:内容\r\n3:用户\r\n4:系统\r\n5:邮件\r\n6:积分规则\r\n7:微信配置', '15');
INSERT INTO `th_config` VALUES ('21', 'HOOKS_TYPE', '3', '钩子的类型', '4', '', '类型 1-用于扩展显示内容，2-用于扩展业务处理', '1379313397', '1379313407', '1', '1:视图\r\n2:控制器', '6');
INSERT INTO `th_config` VALUES ('26', 'USER_ALLOW_REGISTER', '4', '是否允许用户注册', '3', '0:关闭注册\r\n1:允许注册', '是否开放用户注册', '1379504487', '1379504580', '1', '1', '3');
INSERT INTO `th_config` VALUES ('28', 'DATA_BACKUP_PATH', '1', '数据库备份根路径', '4', '', '路径必须以 / 结尾', '1381482411', '1381482411', '1', './Data/', '5');
INSERT INTO `th_config` VALUES ('29', 'DATA_BACKUP_PART_SIZE', '0', '数据库备份卷大小', '4', '', '该值用于限制压缩后的分卷最大长度。单位：B；建议设置20M', '1381482488', '1381729564', '1', '20971520', '7');
INSERT INTO `th_config` VALUES ('30', 'DATA_BACKUP_COMPRESS', '4', '数据库备份文件是否启用压缩', '4', '0:不压缩\r\n1:启用压缩', '压缩备份文件需要PHP环境支持gzopen,gzwrite函数', '1381713345', '1381729544', '1', '1', '9');
INSERT INTO `th_config` VALUES ('31', 'DATA_BACKUP_COMPRESS_LEVEL', '4', '数据库备份文件压缩级别', '4', '1:普通\r\n4:一般\r\n9:最高', '数据库备份文件的压缩级别，该配置在开启压缩时生效', '1381713408', '1381713408', '1', '9', '10');
INSERT INTO `th_config` VALUES ('36', 'ADMIN_ALLOW_IP', '2', '后台允许访问IP', '4', '', '多个用逗号分隔，如果不配置表示不限制IP访问', '1387165454', '1387165553', '1', '', '12');
INSERT INTO `th_config` VALUES ('38', 'WEB_SITE', '1', '网站名称', '1', '', '用于邮件,短信,站内信显示', '1388332311', '1388501500', '1', 'Myblog365博客', '0');
INSERT INTO `th_config` VALUES ('39', 'MAIL_TYPE', '4', '邮件类型', '5', '1:SMTP 模块发送', '需要填写SMTP相关内容', '1388332882', '1388931416', '1', '1', '0');
INSERT INTO `th_config` VALUES ('40', 'MAIL_SMTP_HOST', '1', 'SMTP 服务器', '5', '', 'SMTP服务器', '1388332932', '1388332932', '1', 'smtp.163.com', '0');
INSERT INTO `th_config` VALUES ('41', 'MAIL_SMTP_PORT', '0', 'SMTP服务器端口', '5', '', '默认25', '1388332975', '1388332975', '1', '25', '0');
INSERT INTO `th_config` VALUES ('42', 'MAIL_SMTP_USER', '1', 'SMTP服务器用户名', '5', '', '填写完整用户名', '1388333010', '1388333010', '1', 'lamp365@163.com', '0');
INSERT INTO `th_config` VALUES ('43', 'MAIL_SMTP_PASS', '6', 'SMTP服务器密码', '5', '', '填写您的密码', '1388333057', '1389187088', '1', 'lamp7918I', '0');
INSERT INTO `th_config` VALUES ('51', 'PIC_FILE_PATH', '1', '图片文件保存根目录', '4', '', '图片文件保存根目录./目录/', '1388673255', '1388673255', '1', './Uploads/', '0');
INSERT INTO `th_config` VALUES ('46', 'MAIL_SMTP_CE', '1', '邮件发送测试', '5', '', '填写测试邮件地址', '1388334529', '1388584028', '1', '920111264@qq.com', '11');
INSERT INTO `th_config` VALUES ('47', 'MAIL_USER_REG', '5', '注册邮件模板', '5', '', '支持HTML代码', '1388337307', '1389532335', '1', '<p>\r\n	<a href=\"http://kssoulmate.com\" target=\"_blank\">点击进入公司官网</a>\r\n</p>\r\n<p>\r\n	<a href=\"http://zswin.cn\" target=\"_blank\">点击进入产品官网</a>\r\n</p>\r\n<p>\r\n	<span style=\"color:#E53333,;\">当您收到这封邮件，表明您已注册成功，以上为您的用户名和密码。。。。祝您生活愉快····</span>\r\n</p>', '55');
INSERT INTO `th_config` VALUES ('24', 'NICK_NAME_BAOLIU', '1', '保留昵称', '3', '', '禁止注册昵称,用\" , \"号隔开', '1388845937', '1388845937', '1', '管理员,测试,admin,垃圾', '0');
INSERT INTO `th_config` VALUES ('52', 'USER_NAME_BAOLIU', '1', '保留用户名', '3', '', '禁止注册用户名,用\" , \"号隔开', '1388845937', '1388845937', '1', '管理员,测试,admin,垃圾', '0');
INSERT INTO `th_config` VALUES ('53', 'USER_REG_TIME', '0', '注册时间限制', '3', '', '同一IP注册时间限制，防恶意注册，格式分钟', '1388847715', '1388847715', '1', '2', '0');
INSERT INTO `th_config` VALUES ('48', 'VERIFY_OPEN', '1', '验证码配置', '4', '', '验证码配置，填写数字，数字中间用半角逗号隔开。1:注册显示2:登陆显示3:后台登陆显示', '1388500332', '1388500800', '1', '1,2,3', '0');
INSERT INTO `th_config` VALUES ('55', 'USER_RESPASS', '5', '密码找回模板', '3', '', '密码找回文本', '1396191234', '1396191234', '1', '<span style=\"color:#009900,;\">请点击以下链接找回密码，如无反应，请将链接地址复制到浏览器中打开(有效时间5分钟)</span>', '9');
INSERT INTO `th_config` VALUES ('56', 'CATE_TYPE', '3', '分类类型', '4', '', '分类类型', '1379228036', '1384418383', '1', '1:博客\r\n', '15');
INSERT INTO `th_config` VALUES ('58', 'ARTSCORE', '0', '发布文章积分', '6', '', '', '1419497086', '1419497129', '1', '1', '1');
INSERT INTO `th_config` VALUES ('59', 'REGSCORE', '0', '注册积分', '6', '', '', '1419497168', '1419497168', '1', '4', '2');
INSERT INTO `th_config` VALUES ('60', 'WEB_THEME', '1', '模板名称', '1', '', '请填写模板的文件夹名称，默认为simple。模板均在根目录下的Theme文件夹下。', '1420474619', '1420474619', '1', 'simple', '2');
INSERT INTO `th_config` VALUES ('61', 'WEB_DIR', '1', '网站目录', '1', '', '仅在网站安装在非根目录时需要填写并区分大小写！如果是根目录安装的网站，请留空.', '1420535295', '1420535295', '1', '', '12');
INSERT INTO `th_config` VALUES ('62', 'SYSTEM_UPDATRE_VERSION', '1', '版本号', '0', '', '记录当前系统的版本号，这是与官方比较是否有升级包的唯一标识，不熟悉者只勿改变其数值', '1420802515', '1420802814', '1', '20150218', '1');
INSERT INTO `th_config` VALUES ('63', 'CREATMENU', '4', '重新创建菜单', '7', '0:否\r\n1:是', '当你的推荐id改变时开启此项，菜单更新后关闭即可！', '1420975220', '1420975471', '1', '0', '3');
INSERT INTO `th_config` VALUES ('64', 'WXCATEID', '1', '分类推荐ID', '7', '', '用半角逗号隔开，不宜太多！', '1420975258', '1420975487', '1', '', '5');
INSERT INTO `th_config` VALUES ('65', 'WXARTID', '1', '每日精选推荐ID', '7', '', ' 半角逗号隔开，不宜太多！', '1420975350', '1420975481', '1', '', '4');
INSERT INTO `th_config` VALUES ('66', 'TOKEN', '1', '微信公众号token', '7', '', '微信公众平台的token配置必须和此处保持一致！', '1420975387', '1420975464', '1', '', '2');
INSERT INTO `th_config` VALUES ('67', 'WXAPPSECRET', '1', '微信公众号appsecret', '7', '', '', '1420975417', '1420975417', '1', '', '0');
INSERT INTO `th_config` VALUES ('68', 'WXAPPID', '1', '微信公众号appid', '7', '', '', '1420975435', '1420975455', '1', '', '1');
INSERT INTO `th_config` VALUES ('69', 'WXWELCOME', '1', '关注后的欢迎词', '7', '', '', '1420975435', '1420975455', '1', '', '9');
INSERT INTO `th_config` VALUES ('70', 'AESKEY', '1', 'encodingAesKey', '7', '', '', '1420975435', '1420975455', '1', '', '2');
INSERT INTO `th_config` VALUES ('71', 'WXUSER', '1', '微信公众号用户', '7', '', '', '1420975435', '1420975455', '1', '', '2');
INSERT INTO `th_config` VALUES ('72', 'WXPASS', '6', '公众号密码', '7', '', '', '1420975435', '1420975455', '1', 'MDAwMDAwMDAwMIyGiqWYZJN9ho%Wf4Wpq5mGh9Jqs2Wd3IdnnZe50WlqmXhwz4pmu2iLanSpgbuWrpN20oDEi37dh2iCsLm9h6qanajPgoikkJd_eKWKq82Zl5y4rMOLht2Si6meyNKDrJJjgpSKZ6yviaF7qJWUt6yThrNou3qY3ZKLf7C6rWVqmXWS242Ll6CWo3SflZbR2JNi1qC5ZYewh2alrrWqf5aadY6YgnysholnqqCXqK%6k4bAqbuLnbOEZoOvudGlppJkereHZdFqmo%MoYy5vpmVh9aNt4uClpaMg6XJ0WqrnIWG24uIsJmIZ6qegZSymJWeyozEimK9h2d%r7Sqf4KadZKnimaasoppjKSK0a%5f53WhMKHd9yCsIeXvb2LaJl1gsuWfKyxi2p4noG7q86MeNFnuIqV2ZaOf6XImK2qm4l%p4t8qIR_i4yjgauvqJWJsGa1embNhWaHl8iWbmeciIqrlnykr4ikpp2W0buviZ%4fMSKYtp7i2Ksvb6gZpyfetuHoZejiGdnYYHPydWXnc2hwoqUloOwd6%_un%tmpycsph8tK%WjKqlgaudow', '2');

-- -----------------------------
-- Table structure for `th_district`
-- -----------------------------
DROP TABLE IF EXISTS `th_district`;
CREATE TABLE `th_district` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `level` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `upid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=45052 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC COMMENT='中国省市区乡镇数据表';


-- -----------------------------
-- Table structure for `th_file`
-- -----------------------------
DROP TABLE IF EXISTS `th_file`;
CREATE TABLE `th_file` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '文件ID',
  `name` char(30) NOT NULL DEFAULT '' COMMENT '原始文件名',
  `savename` char(20) NOT NULL DEFAULT '' COMMENT '保存名称',
  `savepath` char(30) NOT NULL DEFAULT '' COMMENT '文件保存路径',
  `ext` char(5) NOT NULL DEFAULT '' COMMENT '文件后缀',
  `mime` char(40) NOT NULL DEFAULT '' COMMENT '文件mime类型',
  `size` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '文件大小',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `location` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '文件保存位置',
  `create_time` int(10) unsigned NOT NULL COMMENT '上传时间',
  `download` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_md5` (`md5`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='文件表';


-- -----------------------------
-- Table structure for `th_focus`
-- -----------------------------
DROP TABLE IF EXISTS `th_focus`;
CREATE TABLE `th_focus` (
  `id` int(10) unsigned NOT NULL COMMENT '用户ID',
  `rowid` char(32) NOT NULL COMMENT '事件id',
  `type` tinyint(4) DEFAULT '0' COMMENT '0用户1文章2标签3分类',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '安装时间'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户关注表';


-- -----------------------------
-- Table structure for `th_group`
-- -----------------------------
DROP TABLE IF EXISTS `th_group`;
CREATE TABLE `th_group` (
  `id` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(25) NOT NULL,
  `title` varchar(50) NOT NULL,
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0',
  `icon` varchar(50) NOT NULL DEFAULT 'icon-bar-chart',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=500 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_group`
-- -----------------------------
INSERT INTO `th_group` VALUES ('16', 'System', '系统管理', '1222841259', '0', '1', '7', 'icon-cog');
INSERT INTO `th_group` VALUES ('3', 'Info', '扩展管理', '1373021663', '0', '1', '8', 'icon-puzzle-piece');
INSERT INTO `th_group` VALUES ('4', 'User', '用户管理', '1373021663', '0', '1', '6', 'icon-group');
INSERT INTO `th_group` VALUES ('7', 'Content', '内容管理', '1373021663', '0', '1', '5', 'icon-book');

-- -----------------------------
-- Table structure for `th_hooks`
-- -----------------------------
DROP TABLE IF EXISTS `th_hooks`;
CREATE TABLE `th_hooks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `name` varchar(40) NOT NULL DEFAULT '' COMMENT '钩子名称',
  `description` text NOT NULL COMMENT '描述',
  `type` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `addons` varchar(255) NOT NULL DEFAULT '' COMMENT '钩子挂载的插件 ''，''分割',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=502 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_hooks`
-- -----------------------------
INSERT INTO `th_hooks` VALUES ('1', 'pageHeader', '页面header钩子，一般用于加载插件CSS文件和代码', '1', '0', '');
INSERT INTO `th_hooks` VALUES ('2', 'pageFooter', '页面footer钩子，一般用于加载插件JS文件和JS代码', '1', '0', 'SuperLinks,cnzz');
INSERT INTO `th_hooks` VALUES ('14', 'topicComment', '评论提交方式扩展钩子。', '1', '1380163518', '');
INSERT INTO `th_hooks` VALUES ('16', 'app_begin', '应用开始', '2', '1384481614', '');
INSERT INTO `th_hooks` VALUES ('21', 'localComment', '本地评论插件', '1', '1399440321', 'LocalComment');
INSERT INTO `th_hooks` VALUES ('24', 'syncLogin', '第三方登陆', '1', '1403700633', '');
INSERT INTO `th_hooks` VALUES ('25', 'syncMeta', '第三方登陆meta接口', '1', '1403700633', '');
INSERT INTO `th_hooks` VALUES ('27', 'J_China_City', '每个系统都需要的一个中国省市区三级联动插件。', '1', '1406690225', '');
INSERT INTO `th_hooks` VALUES ('28', 'Advs', '广告位插件', '1', '1406690225', 'Advs');
INSERT INTO `th_hooks` VALUES ('29', 'imageSlider', '图片轮播钩子', '1', '1406690225', 'ImageSlider');
INSERT INTO `th_hooks` VALUES ('30', 'friendLink', '友情链接插件', '1', '1406690225', 'SuperLinks');
INSERT INTO `th_hooks` VALUES ('13', 'AdminIndex', '默认后台插件', '1', '1382596073', 'Advertising');
INSERT INTO `th_hooks` VALUES ('4', 'documentDetailAfter', '末尾显示', '1', '0', 'Fancybox');
INSERT INTO `th_hooks` VALUES ('3', 'avatar', '前台显示', '1', '0', 'Avatar');
INSERT INTO `th_hooks` VALUES ('31', 'AdminJChinaCity', '后台中国省市区三级联动插件。', '1', '1406690225', '');
INSERT INTO `th_hooks` VALUES ('500', 'seo', '方便站长自定义seo关键词等', '1', '1430141850', 'seo');
INSERT INTO `th_hooks` VALUES ('501', 'Qiniu', '用于七牛存储的上传', '1', '1430404197', 'Qiniu');

-- -----------------------------
-- Table structure for `th_local_comment`
-- -----------------------------
DROP TABLE IF EXISTS `th_local_comment`;
CREATE TABLE `th_local_comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `app` text NOT NULL,
  `con` text NOT NULL,
  `row_id` int(11) NOT NULL,
  `parse` int(11) NOT NULL DEFAULT '0',
  `content` varchar(1000) NOT NULL,
  `create_time` int(11) NOT NULL,
  `pid` int(11) NOT NULL DEFAULT '0',
  `ding` int(10) DEFAULT '0' COMMENT '支持',
  `cai` int(10) DEFAULT '0' COMMENT '反对',
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_local_comment`
-- -----------------------------
INSERT INTO `th_local_comment` VALUES ('1', '1', 'Home', 'Article', '2', '0', '沙发,测试一下评论，只是测试一下。祝贺网站正式发布。', '1430191509', '0', '7', '1', '1');
INSERT INTO `th_local_comment` VALUES ('2', '0', 'Home', 'Article', '2', '0', '不错', '1430229513', '0', '2', '1', '1');

-- -----------------------------
-- Table structure for `th_member`
-- -----------------------------
DROP TABLE IF EXISTS `th_member`;
CREATE TABLE `th_member` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `nickname` char(16) NOT NULL DEFAULT '' COMMENT '昵称',
  `sex` tinyint(3) unsigned NOT NULL DEFAULT '0' COMMENT '性别',
  `birthday` date NOT NULL DEFAULT '0000-00-00' COMMENT '生日',
  `qq` char(10) NOT NULL DEFAULT '' COMMENT 'qq号',
  `score` mediumint(8) NOT NULL DEFAULT '0' COMMENT '用户积分',
  `login` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '会员状态',
  `signature` text,
  `tox_money` int(11) NOT NULL DEFAULT '0',
  `pos_province` int(11) NOT NULL DEFAULT '0',
  `pos_city` int(11) NOT NULL DEFAULT '0',
  `pos_district` int(11) NOT NULL DEFAULT '0',
  `pos_community` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`uid`),
  KEY `status` (`status`),
  KEY `name` (`nickname`)
) ENGINE=MyISAM AUTO_INCREMENT=501 DEFAULT CHARSET=utf8 COMMENT='会员表';

-- -----------------------------
-- Records of `th_member`
-- -----------------------------
INSERT INTO `th_member` VALUES ('1', 'Kevin', '0', '0000-00-00', '', '0', '16', '0', '1430139994', '1991957711', '1430396894', '1', '让学习成为一种习惯，让知识转变为自身价值！', '0', '0', '0', '0', '0');
INSERT INTO `th_member` VALUES ('500', '小辉', '0', '0000-00-00', '', '2', '5', '3683950121', '1430215541', '3683950121', '1430298884', '1', '', '0', '0', '0', '0', '0');

-- -----------------------------
-- Table structure for `th_message`
-- -----------------------------
DROP TABLE IF EXISTS `th_message`;
CREATE TABLE `th_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_uid` int(11) NOT NULL,
  `to_uid` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `create_time` int(11) NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT '0系统消息,1用户消息,2应用消息',
  `is_read` tinyint(4) NOT NULL,
  `status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COMMENT='消息表';

-- -----------------------------
-- Records of `th_message`
-- -----------------------------
INSERT INTO `th_message` VALUES ('1', '0', '500', '注册成功', '恭喜您！您已经注册成功，请尽快<a href=\"/index.php/ucenter/yzmail.html\">验证邮箱地址</a>,第一时间获取网站动态！', '1430215541', '0', '1', '1');

-- -----------------------------
-- Table structure for `th_mrole`
-- -----------------------------
DROP TABLE IF EXISTS `th_mrole`;
CREATE TABLE `th_mrole` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `ename` varchar(5) DEFAULT NULL,
  `score` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '积分',
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parentId` (`pid`),
  KEY `ename` (`ename`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_mrole`
-- -----------------------------
INSERT INTO `th_mrole` VALUES ('1', '普通会员', '0', '1', '', '', '0', '1208784792', '1373020066');

-- -----------------------------
-- Table structure for `th_mrole_user`
-- -----------------------------
DROP TABLE IF EXISTS `th_mrole_user`;
CREATE TABLE `th_mrole_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_mrole_user`
-- -----------------------------
INSERT INTO `th_mrole_user` VALUES ('1', '500');

-- -----------------------------
-- Table structure for `th_mroleconfig`
-- -----------------------------
DROP TABLE IF EXISTS `th_mroleconfig`;
CREATE TABLE `th_mroleconfig` (
  `id` int(10) unsigned NOT NULL COMMENT 'mroleID',
  `value` text NOT NULL COMMENT '配置值',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `th_nav`
-- -----------------------------
DROP TABLE IF EXISTS `th_nav`;
CREATE TABLE `th_nav` (
  `id` smallint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `controll` varchar(50) NOT NULL,
  `action` varchar(50) NOT NULL,
  `status` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `win` tinyint(1) unsigned NOT NULL DEFAULT '1',
  `url` varchar(255) DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `sort` smallint(3) unsigned NOT NULL DEFAULT '0',
  `cid` int(10) unsigned NOT NULL DEFAULT '0',
  `gid` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=504 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_nav`
-- -----------------------------
INSERT INTO `th_nav` VALUES ('1', '首页', 'Index', 'index', '1', '0', 'U(Index/index)', '2', '999', '1', '1');
INSERT INTO `th_nav` VALUES ('2', '标签', 'Index', 'alltag', '1', '0', 'U(Index/alltag)', '2', '998', '1', '1');
INSERT INTO `th_nav` VALUES ('500', 'PHP编程', '', '', '1', '1', 'ZSU(\"/artlist/\"1,\"Index/artlist\",array(\"cid\"=>1))', '0', '500', '1', '1');
INSERT INTO `th_nav` VALUES ('501', 'Mysql', '', '', '1', '1', 'ZSU(\"/artlist/\"2,\"Index/artlist\",array(\"cid\"=>2))', '0', '400', '2', '1');
INSERT INTO `th_nav` VALUES ('502', 'Linux', '', '', '1', '1', 'ZSU(\"/artlist/\"3,\"Index/artlist\",array(\"cid\"=>3))', '0', '300', '3', '1');
INSERT INTO `th_nav` VALUES ('503', '个人随笔', '', '', '1', '1', 'ZSU(\"/artlist/\"4,\"Index/artlist\",array(\"cid\"=>4))', '0', '200', '4', '1');

-- -----------------------------
-- Table structure for `th_node`
-- -----------------------------
DROP TABLE IF EXISTS `th_node`;
CREATE TABLE `th_node` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `title` varchar(50) DEFAULT NULL,
  `status` tinyint(1) DEFAULT '0',
  `remark` varchar(255) DEFAULT NULL,
  `sort` smallint(6) unsigned DEFAULT NULL,
  `pid` smallint(6) unsigned NOT NULL,
  `level` tinyint(1) unsigned NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT '0',
  `group_id` int(10) unsigned DEFAULT '0',
  `icon` varchar(50) NOT NULL DEFAULT 'icon-bar-chart',
  PRIMARY KEY (`id`),
  KEY `level` (`level`),
  KEY `pid` (`pid`),
  KEY `status` (`status`),
  KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=500 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_node`
-- -----------------------------
INSERT INTO `th_node` VALUES ('7', 'Member', '用户管理', '1', '', '0', '1', '2', '0', '4', 'icon-user');
INSERT INTO `th_node` VALUES ('6', 'Role', '管理组', '1', '', '2', '1', '2', '0', '4', ' icon-cloud-upload');
INSERT INTO `th_node` VALUES ('2', 'Node', '节点管理', '1', '', '3', '1', '2', '0', '16', 'icon-bullseye');
INSERT INTO `th_node` VALUES ('84', 'Group', '一级菜单管理', '1', '', '4', '1', '2', '0', '16', 'icon-trello');
INSERT INTO `th_node` VALUES ('92', 'access', '授权', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('93', 'user', '用户列表', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('1', 'Admin', '系统菜单', '1', '', '0', '0', '1', '0', '0', '');
INSERT INTO `th_node` VALUES ('8', 'Database', '数据备份', '1', '', '5', '1', '2', '0', '16', 'icon-archive');
INSERT INTO `th_node` VALUES ('9', 'Dataimport', '数据恢复', '1', '', '6', '1', '2', '0', '16', 'icon-asterisk');
INSERT INTO `th_node` VALUES ('111', 'selectedDelete', '批量删除', '1', '', '10', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('112', 'selectedDelete', '批量删除', '1', '', '10', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('113', 'selectedDelete', '批量删除', '1', '', '10', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('114', 'selectedDelete', '批量删除', '1', '', '10', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('115', 'importxls', '导入数据', '1', '', '11', '4', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('116', 'outxls', '导出数据', '1', '', '12', '4', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('118', 'Addons', '插件管理', '1', '', '0', '1', '2', '0', '3', 'icon-tasks');
INSERT INTO `th_node` VALUES ('119', 'create', '创建', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('120', 'checkForm', '检测创建', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('121', 'preview', '预览', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('122', 'build', '快速生成插件', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('123', 'config', '设置', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('124', 'disable', '禁用', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('125', 'enable', '启用', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('126', 'install', '安装', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('127', 'uninstall', '卸载', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('128', 'saveconfig', '更新配置', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('129', 'adminList', '插件后台列表', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('130', 'execute', 'URL方式访问插件', '1', '', '12', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('131', 'Hooks', '钩子管理', '1', '', '2', '1', '2', '0', '3', 'icon-vk');
INSERT INTO `th_node` VALUES ('132', 'add', '新增钩子', '1', '', '12', '131', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('133', 'edit', '编辑钩子', '1', '', '12', '131', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('134', 'foreverdelete', '删除', '1', '', '0', '131', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('135', 'AddonsAdmin', '已装插件管理', '1', '', '1', '1', '2', '0', '3', 'icon-cutlery');
INSERT INTO `th_node` VALUES ('170', 'index', '列表', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('171', 'add', '新增', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('172', 'edit', '编辑', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('173', 'insert', '写入', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('174', 'update', '更新', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('175', 'forbid', '禁用', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('176', 'resume', '恢复', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('177', 'foreverdelete', '删除', '1', '', '0', '84', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('178', 'index', '列表', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('179', 'add', '新增', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('180', 'edit', '编辑', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('181', 'insert', '写入', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('182', 'update', '更新', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('183', 'forbid', '禁用', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('184', 'resume', '恢复', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('185', 'foreverdelete', '删除', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('186', 'index', '列表', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('187', 'add', '新增', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('188', 'edit', '编辑', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('189', 'insert', '写入', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('190', 'update', '更新', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('191', 'forbid', '禁用', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('192', 'resume', '恢复', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('193', 'foreverdelete', '删除', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('194', 'index', '列表', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('195', 'add', '新增', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('196', 'edit', '编辑', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('197', 'insert', '写入', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('198', 'update', '更新', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('199', 'forbid', '禁用', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('200', 'resume', '恢复', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('201', 'foreverdelete', '删除', '1', '', '0', '2', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('205', 'resetPwd', '保存修改密码', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('206', 'password', '修改密码', '1', '', '0', '7', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('277', 'setGroupAll', '设置权限', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('278', 'setUser', '设置用户', '1', '', '0', '6', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('283', 'Syslogs', '日志管理', '1', '', '4', '1', '2', '0', '16', 'icon-pencil-square-o');
INSERT INTO `th_node` VALUES ('284', 'index', '列表', '1', '', '0', '283', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('285', 'Config', '网站设置', '1', 'group', '0', '1', '2', '0', '16', 'icon-flickr');
INSERT INTO `th_node` VALUES ('286', 'Config', '配置管理', '1', '', '1', '1', '2', '0', '16', 'icon-adn');
INSERT INTO `th_node` VALUES ('287', 'edit', '编辑', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('288', 'foreverdelete', '删除', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('289', 'add', '新增', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('290', 'update', '更新', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('291', 'insert', '写入', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('292', 'sort', '排序', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('293', 'selectedDelete', '批量删除', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('294', 'Article', '博客管理', '1', '', '4', '1', '2', '0', '7', 'icon-instagram');
INSERT INTO `th_node` VALUES ('295', 'index', '列表', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('296', 'add', '新增', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('297', 'edit', '编辑', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('298', 'insert', '写入', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('299', 'update', '更新', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('300', 'forbid', '禁用', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('301', 'resume', '恢复', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('302', 'foreverdelete', '删除', '1', '', '0', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('303', 'selectedDelete', '批量删除', '1', '', '10', '294', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('304', 'Cate', '分类管理', '1', '', '4', '1', '2', '0', '7', 'icon-magic');
INSERT INTO `th_node` VALUES ('305', 'index', '列表', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('306', 'add', '新增', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('307', 'edit', '编辑', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('308', 'insert', '写入', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('309', 'update', '更新', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('310', 'forbid', '禁用', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('311', 'resume', '恢复', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('312', 'foreverdelete', '删除', '1', '', '0', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('313', 'selectedDelete', '批量删除', '1', '', '10', '304', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('314', 'Mrole', '会员组', '1', '', '4', '1', '2', '0', '4', 'icon-male');
INSERT INTO `th_node` VALUES ('315', 'index', '列表', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('316', 'add', '新增', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('317', 'edit', '编辑', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('318', 'insert', '写入', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('319', 'update', '更新', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('320', 'forbid', '禁用', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('321', 'resume', '恢复', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('322', 'foreverdelete', '删除', '1', '', '0', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('323', 'config', '权限', '1', '', '10', '314', '3', '0', '7', '');
INSERT INTO `th_node` VALUES ('324', 'sort', '排序', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('325', 'save', '保存网站设置', '1', '', '10', '286', '3', '0', '16', '');
INSERT INTO `th_node` VALUES ('326', 'index', '列表', '1', '', '0', '286', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('327', 'group', '网站设置', '1', '', '0', '286', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('328', 'index', '列表', '1', '', '0', '8', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('329', 'index', '列表', '1', '', '0', '9', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('330', 'index', '列表', '1', '', '0', '131', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('331', 'index', '列表', '1', '', '0', '118', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('333', 'Urlset', 'URL设置', '1', '', '0', '1', '2', '0', '16', 'icon-instagram');
INSERT INTO `th_node` VALUES ('334', 'index', '列表', '1', '', '0', '333', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('335', 'Nav', '导航管理', '1', '', '4', '1', '2', '0', '16', 'icon-globe');
INSERT INTO `th_node` VALUES ('336', 'index', '列表', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('337', 'add', '新增', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('338', 'edit', '编辑', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('339', 'insert', '写入', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('340', 'update', '更新', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('341', 'forbid', '禁用', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('342', 'resume', '恢复', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('343', 'foreverdelete', '删除', '1', '', '0', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('344', 'selectedDelete', '批量删除', '1', '', '10', '335', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('346', 'Message', '消息管理', '1', '', '4', '1', '2', '0', '7', 'icon-bell');
INSERT INTO `th_node` VALUES ('347', 'index', '列表', '1', '', '0', '346', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('348', 'add', '发送', '1', '', '0', '346', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('349', 'insert', '写入', '1', '', '0', '346', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('350', 'foreverdelete', '删除', '1', '', '0', '346', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('351', 'selectedDelete', '批量删除', '1', '', '10', '346', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('352', 'Comments', '评论管理', '1', '', '4', '1', '2', '0', '7', 'icon-reply-all');
INSERT INTO `th_node` VALUES ('353', 'index', '列表', '1', '', '0', '352', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('354', 'foreverdelete', '删除', '1', '', '0', '352', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('355', 'selectedDelete', '批量删除', '1', '', '10', '352', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('356', 'Tags', '标签管理', '1', '', '4', '1', '2', '0', '7', 'icon-tags');
INSERT INTO `th_node` VALUES ('357', 'index', '列表', '1', '', '0', '356', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('358', 'foreverdelete', '删除', '1', '', '0', '356', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('359', 'selectedDelete', '批量删除', '1', '', '10', '356', '3', '0', '0', '');
INSERT INTO `th_node` VALUES ('360', 'Update', '系统升级', '1', '', '4', '1', '2', '0', '16', 'icon-rocket');
INSERT INTO `th_node` VALUES ('361', 'index', '列表', '1', '', '0', '360', '3', '0', '0', '');

-- -----------------------------
-- Table structure for `th_picture`
-- -----------------------------
DROP TABLE IF EXISTS `th_picture`;
CREATE TABLE `th_picture` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键id自增',
  `path` varchar(255) NOT NULL DEFAULT '' COMMENT '路径',
  `url` varchar(255) NOT NULL DEFAULT '' COMMENT '图片链接',
  `md5` char(32) NOT NULL DEFAULT '' COMMENT '文件md5',
  `sha1` char(40) NOT NULL DEFAULT '' COMMENT '文件 sha1编码',
  `status` tinyint(2) NOT NULL DEFAULT '0' COMMENT '状态',
  `create_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `th_role`
-- -----------------------------
DROP TABLE IF EXISTS `th_role`;
CREATE TABLE `th_role` (
  `id` smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `pid` smallint(6) DEFAULT NULL,
  `status` tinyint(1) unsigned DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `ename` varchar(5) DEFAULT NULL,
  `create_time` int(11) unsigned NOT NULL,
  `update_time` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `parentId` (`pid`),
  KEY `ename` (`ename`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=500 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_role`
-- -----------------------------
INSERT INTO `th_role` VALUES ('1', '超级管理员', '0', '1', '', '', '1208784792', '1373020066');
INSERT INTO `th_role` VALUES ('2', '管理员', '0', '1', '', '', '1215496283', '1373020058');
INSERT INTO `th_role` VALUES ('3', '审核员', '0', '1', '', '', '1307071286', '1373020052');

-- -----------------------------
-- Table structure for `th_role_user`
-- -----------------------------
DROP TABLE IF EXISTS `th_role_user`;
CREATE TABLE `th_role_user` (
  `role_id` mediumint(9) unsigned DEFAULT NULL,
  `user_id` char(32) DEFAULT NULL,
  KEY `group_id` (`role_id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_role_user`
-- -----------------------------
INSERT INTO `th_role_user` VALUES ('1', '1');

-- -----------------------------
-- Table structure for `th_sync_login`
-- -----------------------------
DROP TABLE IF EXISTS `th_sync_login`;
CREATE TABLE `th_sync_login` (
  `uid` int(11) NOT NULL,
  `type_uid` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `oauth_token` varchar(255) NOT NULL,
  `oauth_token_secret` varchar(255) NOT NULL,
  `is_sync` tinyint(4) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `th_syslogs`
-- -----------------------------
DROP TABLE IF EXISTS `th_syslogs`;
CREATE TABLE `th_syslogs` (
  `id` int(12) NOT NULL AUTO_INCREMENT,
  `modulename` varchar(30) DEFAULT '',
  `actionname` varchar(30) DEFAULT '',
  `opname` varchar(30) DEFAULT '',
  `message` varchar(30) DEFAULT '',
  `userid` smallint(5) NOT NULL DEFAULT '0',
  `username` varchar(64) DEFAULT '',
  `userip` varchar(40) DEFAULT NULL,
  `create_time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=134 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `th_syslogs`
-- -----------------------------
INSERT INTO `th_syslogs` VALUES ('22', '公共模块', 'Login', '用户登录', '成功', '1', 'admin', '219.148.158.41', '1430140007');
INSERT INTO `th_syslogs` VALUES ('23', '分类管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141579');
INSERT INTO `th_syslogs` VALUES ('24', '分类管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141602');
INSERT INTO `th_syslogs` VALUES ('25', '分类管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141624');
INSERT INTO `th_syslogs` VALUES ('26', '分类管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141639');
INSERT INTO `th_syslogs` VALUES ('27', '导航管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141709');
INSERT INTO `th_syslogs` VALUES ('28', '导航管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141737');
INSERT INTO `th_syslogs` VALUES ('29', '导航管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141750');
INSERT INTO `th_syslogs` VALUES ('30', '导航管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430141763');
INSERT INTO `th_syslogs` VALUES ('31', '导航管理', '更新', '', '编辑成功!', '1', 'admin', '219.148.158.41', '1430141840');
INSERT INTO `th_syslogs` VALUES ('32', '插件管理', '安装', '', '\"seo设置\"插件安装成功!', '1', 'admin', '219.148.158.41', '1430141850');
INSERT INTO `th_syslogs` VALUES ('33', '插件管理', '安装', '', '\"友情链接\"插件安装成功!', '1', 'admin', '219.148.158.41', '1430141863');
INSERT INTO `th_syslogs` VALUES ('34', '插件管理', '安装', '', '\"图片轮播\"插件安装成功!', '1', 'admin', '219.148.158.41', '1430141868');
INSERT INTO `th_syslogs` VALUES ('35', '插件管理', '安装', '', '\"广告位置\"插件安装成功!', '1', 'admin', '219.148.158.41', '1430141874');
INSERT INTO `th_syslogs` VALUES ('36', '插件管理', '安装', '', '\"广告管理\"插件安装成功!', '1', 'admin', '219.148.158.41', '1430141879');
INSERT INTO `th_syslogs` VALUES ('37', '插件管理', '安装', '', '\"站长统计\"插件安装成功!', '1', 'admin', '219.148.158.41', '1430141891');
INSERT INTO `th_syslogs` VALUES ('38', '博客管理', '写入', '', '新增成功!', '1', 'admin', '219.148.158.41', '1430143622');
INSERT INTO `th_syslogs` VALUES ('39', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430144332');
INSERT INTO `th_syslogs` VALUES ('40', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430144430');
INSERT INTO `th_syslogs` VALUES ('41', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430144495');
INSERT INTO `th_syslogs` VALUES ('42', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430145123');
INSERT INTO `th_syslogs` VALUES ('43', '网站设置', '保存网站设置', '', '网站配置保存成功！', '1', 'admin', '113.31.38.190', '1430157311');
INSERT INTO `th_syslogs` VALUES ('44', '网站设置', '保存网站设置', '', '网站配置保存成功！', '1', 'admin', '113.31.38.190', '1430157313');
INSERT INTO `th_syslogs` VALUES ('45', '网站设置', '保存网站设置', '', '网站配置保存成功！', '1', 'admin', '113.31.38.190', '1430157365');
INSERT INTO `th_syslogs` VALUES ('46', '博客管理', '写入', '', '新增成功!', '1', 'admin', '113.31.38.190', '1430157809');
INSERT INTO `th_syslogs` VALUES ('47', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430157852');
INSERT INTO `th_syslogs` VALUES ('48', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430157911');
INSERT INTO `th_syslogs` VALUES ('49', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430157945');
INSERT INTO `th_syslogs` VALUES ('50', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430158004');
INSERT INTO `th_syslogs` VALUES ('51', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430158057');
INSERT INTO `th_syslogs` VALUES ('52', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430158195');
INSERT INTO `th_syslogs` VALUES ('53', '公共模块', 'login', '用户登录', '成功', '1', 'admin', '219.148.158.41', '1430185431');
INSERT INTO `th_syslogs` VALUES ('54', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430185705');
INSERT INTO `th_syslogs` VALUES ('55', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430187243');
INSERT INTO `th_syslogs` VALUES ('56', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430187329');
INSERT INTO `th_syslogs` VALUES ('57', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430187342');
INSERT INTO `th_syslogs` VALUES ('58', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430188106');
INSERT INTO `th_syslogs` VALUES ('59', '博客管理', '更新', '', '修改成功!', '1', 'admin', '219.148.158.41', '1430188194');
INSERT INTO `th_syslogs` VALUES ('60', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430200651');
INSERT INTO `th_syslogs` VALUES ('61', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430210199');
INSERT INTO `th_syslogs` VALUES ('62', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430211946');
INSERT INTO `th_syslogs` VALUES ('63', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430212302');
INSERT INTO `th_syslogs` VALUES ('64', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430212626');
INSERT INTO `th_syslogs` VALUES ('65', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430212667');
INSERT INTO `th_syslogs` VALUES ('66', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430212716');
INSERT INTO `th_syslogs` VALUES ('67', '网站设置', '保存网站设置', '', '网站配置保存成功！', '1', 'admin', '219.148.158.41', '1430215885');
INSERT INTO `th_syslogs` VALUES ('68', '网站设置', '保存网站设置', '', '网站配置保存成功！', '1', 'admin', '219.148.158.41', '1430215897');
INSERT INTO `th_syslogs` VALUES ('69', '公共模块', 'login', '用户登录', '成功', '1', 'admin', '113.31.38.190', '1430229888');
INSERT INTO `th_syslogs` VALUES ('70', '网站设置', '保存网站设置', '', '网站配置保存成功！', '1', 'admin', '113.31.38.190', '1430230078');
INSERT INTO `th_syslogs` VALUES ('71', '公共模块', 'changepwd', '', '密码修改成功！', '1', 'admin', '113.31.38.190', '1430230109');
INSERT INTO `th_syslogs` VALUES ('72', '公共模块', 'logout', '用户退出', '成功', '0', '', '113.31.38.190', '1430235481');
INSERT INTO `th_syslogs` VALUES ('73', '公共模块', 'login', '用户登录', '成功', '1', 'admin', '113.31.38.190', '1430236490');
INSERT INTO `th_syslogs` VALUES ('74', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430236868');
INSERT INTO `th_syslogs` VALUES ('75', '博客管理', '更新', '', '修改成功!', '1', 'admin', '113.31.38.190', '1430238613');
INSERT INTO `th_syslogs` VALUES ('76', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '113.31.38.190', '1430239473');
INSERT INTO `th_syslogs` VALUES ('77', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '113.31.38.190', '1430239857');
INSERT INTO `th_syslogs` VALUES ('78', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '113.31.38.190', '1430240064');
INSERT INTO `th_syslogs` VALUES ('79', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '113.31.38.190', '1430240241');
INSERT INTO `th_syslogs` VALUES ('80', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '113.31.38.190', '1430240471');
INSERT INTO `th_syslogs` VALUES ('81', '公共模块', 'login', '用户登录', '成功', '1', 'admin', '219.148.158.41', '1430290062');
INSERT INTO `th_syslogs` VALUES ('82', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430290127');
INSERT INTO `th_syslogs` VALUES ('83', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430290315');
INSERT INTO `th_syslogs` VALUES ('84', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430290315');
INSERT INTO `th_syslogs` VALUES ('85', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430290542');
INSERT INTO `th_syslogs` VALUES ('86', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430290609');
INSERT INTO `th_syslogs` VALUES ('87', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'admin', '219.148.158.41', '1430291007');
INSERT INTO `th_syslogs` VALUES ('88', '网站设置', '保存网站设置', '', '网站配置保存成功！', '1', 'admin', '219.148.158.41', '1430295220');
INSERT INTO `th_syslogs` VALUES ('89', '公共模块', 'login', '用户登录', '成功', '1', 'Kevin', '113.31.38.190', '1430323660');
INSERT INTO `th_syslogs` VALUES ('90', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430323664');
INSERT INTO `th_syslogs` VALUES ('91', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430323781');
INSERT INTO `th_syslogs` VALUES ('92', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430324398');
INSERT INTO `th_syslogs` VALUES ('93', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430324529');
INSERT INTO `th_syslogs` VALUES ('94', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430324596');
INSERT INTO `th_syslogs` VALUES ('95', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430324928');
INSERT INTO `th_syslogs` VALUES ('96', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430324963');
INSERT INTO `th_syslogs` VALUES ('97', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325119');
INSERT INTO `th_syslogs` VALUES ('98', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325177');
INSERT INTO `th_syslogs` VALUES ('99', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325210');
INSERT INTO `th_syslogs` VALUES ('100', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325226');
INSERT INTO `th_syslogs` VALUES ('101', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325252');
INSERT INTO `th_syslogs` VALUES ('102', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325283');
INSERT INTO `th_syslogs` VALUES ('103', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325319');
INSERT INTO `th_syslogs` VALUES ('104', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325356');
INSERT INTO `th_syslogs` VALUES ('105', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '113.31.38.190', '1430325587');
INSERT INTO `th_syslogs` VALUES ('106', '公共模块', 'login', '用户登录', '成功', '1', 'Kevin', '219.148.158.41', '1430357751');
INSERT INTO `th_syslogs` VALUES ('107', '公共模块', 'login', '用户登录', '成功', '1', 'Kevin', '219.148.158.41', '1430364138');
INSERT INTO `th_syslogs` VALUES ('108', '公共模块', 'login', '用户登录', '成功', '1', 'Kevin', '219.148.158.41', '1430369759');
INSERT INTO `th_syslogs` VALUES ('109', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '219.148.158.41', '1430370389');
INSERT INTO `th_syslogs` VALUES ('110', '博客管理', '写入', '', '新增成功!', '1', 'Kevin', '219.148.158.41', '1430370722');
INSERT INTO `th_syslogs` VALUES ('111', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '219.148.158.41', '1430370870');
INSERT INTO `th_syslogs` VALUES ('112', '博客管理', '写入', '', '新增成功!', '1', 'Kevin', '219.148.158.41', '1430373726');
INSERT INTO `th_syslogs` VALUES ('113', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '219.148.158.41', '1430373822');
INSERT INTO `th_syslogs` VALUES ('114', '博客管理', 'position', '', '推荐成功！', '1', 'Kevin', '219.148.158.41', '1430373888');
INSERT INTO `th_syslogs` VALUES ('115', '公共模块', 'login', '用户登录', '成功', '1', 'Kevin', '118.186.220.207', '1430396894');
INSERT INTO `th_syslogs` VALUES ('116', '博客管理', '写入', '', '新增成功!', '1', 'Kevin', '118.186.220.207', '1430401656');
INSERT INTO `th_syslogs` VALUES ('117', '博客管理', '更新', '', '修改成功!', '1', 'Kevin', '118.186.220.207', '1430401679');
INSERT INTO `th_syslogs` VALUES ('118', '博客管理', '写入', '', '新增成功!', '1', 'Kevin', '118.186.220.207', '1430402472');
INSERT INTO `th_syslogs` VALUES ('119', '博客管理', '写入', '', '新增成功!', '1', 'Kevin', '118.186.220.207', '1430403359');
INSERT INTO `th_syslogs` VALUES ('120', '插件管理', '安装', '', '\"七牛存储插件\"插件安装成功!', '1', 'Kevin', '118.186.220.207', '1430404197');
INSERT INTO `th_syslogs` VALUES ('121', '插件管理', '更新配置', '', '保存插件设置成功!', '1', 'Kevin', '118.186.220.207', '1430409024');
INSERT INTO `th_syslogs` VALUES ('122', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '118.186.220.207', '1430409793');
INSERT INTO `th_syslogs` VALUES ('123', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '118.186.220.207', '1430410642');
INSERT INTO `th_syslogs` VALUES ('124', '插件管理', '更新配置', '', '保存插件设置成功!', '1', 'Kevin', '118.186.220.207', '1430410863');
INSERT INTO `th_syslogs` VALUES ('125', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '118.186.220.207', '1430410906');
INSERT INTO `th_syslogs` VALUES ('126', '插件管理', '更新配置', '', '保存插件设置成功!', '1', 'Kevin', '118.186.220.207', '1430411183');
INSERT INTO `th_syslogs` VALUES ('127', '插件管理', '更新配置', '', '保存插件设置成功!', '1', 'Kevin', '118.186.220.207', '1430411328');
INSERT INTO `th_syslogs` VALUES ('128', '插件管理', '更新配置', '', '保存插件设置成功!', '1', 'Kevin', '118.186.220.207', '1430411559');
INSERT INTO `th_syslogs` VALUES ('129', '公共模块', 'cleancache', '', '文件夹./Runtime/删除成功;</br>', '1', 'Kevin', '118.186.220.207', '1430411641');
INSERT INTO `th_syslogs` VALUES ('130', '插件管理', '安装', '', '\"图片弹出播放\"插件安装成功!', '1', 'Kevin', '118.186.220.207', '1430412346');
INSERT INTO `th_syslogs` VALUES ('131', '插件管理', '更新配置', '', '保存插件设置成功!', '1', 'Kevin', '118.186.220.207', '1430412444');
INSERT INTO `th_syslogs` VALUES ('132', '博客管理', '写入', '', '新增成功!', '1', 'Kevin', '118.186.220.207', '1430412958');
INSERT INTO `th_syslogs` VALUES ('133', '博客管理', '更新', '', '修改成功!', '1', 'Kevin', '118.186.220.207', '1430413029');

-- -----------------------------
-- Table structure for `th_tags`
-- -----------------------------
DROP TABLE IF EXISTS `th_tags`;
CREATE TABLE `th_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(20) NOT NULL DEFAULT '' COMMENT '标签',
  `num` int(10) DEFAULT '0' COMMENT '标签数',
  `des` varchar(255) NOT NULL DEFAULT '0',
  `img` varchar(255) NOT NULL DEFAULT '0',
  `type` tinyint(1) DEFAULT '0' COMMENT '类型',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `th_ucenter_member`
-- -----------------------------
DROP TABLE IF EXISTS `th_ucenter_member`;
CREATE TABLE `th_ucenter_member` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` char(16) NOT NULL COMMENT '用户名',
  `password` char(32) NOT NULL COMMENT '密码',
  `email` char(32) NOT NULL COMMENT '用户邮箱',
  `face` varchar(200) DEFAULT NULL,
  `mobile` char(15) NOT NULL DEFAULT '0' COMMENT '用户手机',
  `reg_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '注册时间',
  `reg_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '注册IP',
  `last_login_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '最后登录时间',
  `last_login_ip` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后登录IP',
  `update_time` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `status` tinyint(4) DEFAULT '0' COMMENT '用户状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`),
  KEY `status` (`status`)
) ENGINE=MyISAM AUTO_INCREMENT=501 DEFAULT CHARSET=utf8 COMMENT='用户表';

-- -----------------------------
-- Records of `th_ucenter_member`
-- -----------------------------
INSERT INTO `th_ucenter_member` VALUES ('1', 'Kevin', 'bb45ddd9f9063f0864ad0a7f881f2162', '791845283@qq.com', '', '', '1430139994', '3683950121', '1430396894', '1991957711', '1430230108', '1');
INSERT INTO `th_ucenter_member` VALUES ('500', '小辉', '5cddcc95b3430f3394638ed0d024da38', '920111264@qq.com', '', '0', '1430215541', '3683950121', '1430298884', '3683950121', '1430322106', '1');

-- -----------------------------
-- Table structure for `th_user_token`
-- -----------------------------
DROP TABLE IF EXISTS `th_user_token`;
CREATE TABLE `th_user_token` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `token` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `th_userexp`
-- -----------------------------
DROP TABLE IF EXISTS `th_userexp`;
CREATE TABLE `th_userexp` (
  `id` int(10) unsigned NOT NULL COMMENT '用户ID',
  `email` char(32) NOT NULL COMMENT '用户认证邮箱',
  `rztype` tinyint(4) DEFAULT '0' COMMENT '认证类别',
  `rz` tinyint(4) DEFAULT '0' COMMENT '是否认证',
  `signature` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='用户扩展表';

-- -----------------------------
-- Records of `th_userexp`
-- -----------------------------
INSERT INTO `th_userexp` VALUES ('1', '791845283@qq.com', '0', '0', '');
